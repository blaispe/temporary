# R5.10 — richiesta di supervisione indipendente ChatGPT

Esaminare il PCB KiCad reale `R510.kicad_pcb` e verificare in modo indipendente
il lavoro eseguito per eliminare i drill HDI/microvia rifiutati da JLCPCB.

## Stato dichiarato da Codex

- 6 layer di rame;
- 155 footprint e 155/155 riferimenti visibili;
- placement ed Edge.Cuts invariati rispetto a R59;
- microvia residue: 0;
- via passanti: 324;
- ERC: 0;
- schematic/PCB parity: 0;
- DRC: nessun corto o errore di clearance, un warning `copper_sliver`;
- native unconnected: 34;
- stato: **NO-GO / non fabbricabile**.

Codex non ha prodotto Gerber o ZIP JLCPCB perché la connettività non è chiusa.

## Verifiche richieste

1. Aprire e analizzare direttamente `R510.kicad_pcb`, senza basarsi soltanto
   sui report.
2. Confermare che non esistano microvia/blind/buried via residue e che tutti i
   via siano realmente F.Cu-B.Cu PTH.
3. Confermare il conteggio di footprint, riferimenti, layer e unconnected.
4. Controllare il blocker documentato attorno a U3/J8, in particolare:
   - U3 pad 5 `/PMIC_SCL` a (104.000, 116.750) mm;
   - U3 pad 12 `/BQ_QON_N` a (107.250, 118.000) mm;
   - interferenze full-stack con `/BAT_PROTECTED`, `/BQ_STAT`, `/BQ_INT_N`,
     J8 `/OLED_SDA`, `/OLED_SCL` e GND.
5. Verificare che la proposta di modifica locale placement/routing sia davvero
   necessaria o indicare un percorso PTH alternativo concreto e verificabile.
6. Non dichiarare FAB READY finché DRC, unconnected, ERC e parity non sono tutti
   a zero, salvo warning esplicitamente motivati.
7. Produrre un handoff correttivo preciso per Codex con coordinate, layer,
   larghezze, via e ordine operativo delle modifiche consigliate.

## File principali nel pacchetto

- `R510.kicad_pcb` — sorgente PCB autorevole;
- `R5_10_TRUE_HARD_BLOCKER_REPORT.md` — prove e coordinate del blocco;
- `R5_10_FINAL_GATE_REPORT.md` — gate NO-GO;
- `R5_10_DRC_BLOCKED_WIP.json` e `R5_10_ERC_BLOCKED_WIP.json`;
- `R5_10_MICROVIA_TO_THROUGHVIA_AUDIT.csv` — 254 record originali;
- `SHA256_MANIFEST.txt` — hash di tutti i file allegati.

SHA-256 del PCB autorevole:

`1AE80FE0DC4D3EAB149CB9ED179A059E7ECF77B9CD2629A98BF1B779B7115904`
