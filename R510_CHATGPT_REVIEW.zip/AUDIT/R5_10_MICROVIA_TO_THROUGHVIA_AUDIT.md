# R5.10 microvia to through-via audit

Status: **WIP NO-GO / TRUE HARD BLOCKER**

- R59 original microvias inventoried: **254**.
- Unique coordinate/net stacks: **160**.
- R5.10 WIP remaining microvias: **0**.
- R5.10 WIP standard through vias: **324**.
- Copper layers: **6**.
- Final safe WIP unconnected items: **34**.
- Final safe WIP DRC: **0 electrical/clearance errors**, one `copper_sliver` warning.
- The row-level inventory is in `R5_10_MICROVIA_TO_THROUGHVIA_AUDIT.csv`.

The first same-coordinate conversion was rejected because 141 of 160 converted
coordinate/net stacks participated in full-stack clearance, short, hole-clearance
or centering findings.  The working board therefore removed the affected HDI
transitions and rebuilt only the impacted nets with native F.Cu-B.Cu PTH vias.

The conversion reached zero microvia objects, but cannot reach zero ratsnest
without changing the frozen local placement/routing around U3/J8 and other
fine-pitch via-in-pad cells.  See `R5_10_TRUE_HARD_BLOCKER_REPORT.md`.

