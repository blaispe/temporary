# R5.10 schematic/PCB parity — blocked WIP

Native KiCad DRC report `R5_10_DRC_BLOCKED_WIP.json` contains **0 schematic
parity findings**.  The schematic was not modified during the via conversion.

This parity PASS does not override the PCB connectivity NO-GO (34 unconnected).

