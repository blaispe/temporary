# R5.10 regression audit — blocked WIP

- Copper layers: **6**, unchanged.
- Footprints: **155**, unchanged.
- Visible references: **155/155**.
- Hidden references: **0**.
- Footprint position/layer changes versus R59: **0**.
- Edge.Cuts items: **4 versus 4**, geometry equal.
- Remaining microvias: **0**.
- Standard through vias: **324**.
- Schematic modified: **NO**.
- ERC: **0**.
- Schematic/PCB parity findings: **0**.
- U13/U4 placement: unchanged.
- LTE RF route and USB D+/D- topology: not intentionally modified.
- BOM/CPL files: preserved from R59.

Board SHA-256:

`1AE80FE0DC4D3EAB149CB9ED179A059E7ECF77B9CD2629A98BF1B779B7115904`

This audit describes an engineering WIP only.  Fabrication is blocked by 34
native unconnected items.

