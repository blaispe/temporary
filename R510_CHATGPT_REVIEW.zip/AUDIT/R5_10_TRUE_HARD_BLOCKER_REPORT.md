# R5.10 true hard blocker report

Date: 2026-09-01  
Baseline: R59 six-layer release  
Target: standard F.Cu-B.Cu PTH only

## Outcome

The native KiCad board has been converted to **zero microvia objects**, but the
electrical gate is **NO-GO** because 34 native unconnected items remain.  No
Gerber/re-upload package was generated.

The retained WIP checkpoint contains no shorts or clearance errors.  It is the
best safe checkpoint, not a fabrication release.

## Exact geometric blockers

### U3 pad 5 — `/PMIC_SCL` — (104.000, 116.750) mm

The original R59 transition is a fine-pitch via-in-pad microvia.  A 0.25/0.15 mm
full-stack PTH at the pad conflicts on B.Cu with the 0.60 mm
`/BAT_PROTECTED` trunk:

- measured clearance **0.1053–0.1340 mm**;
- required PMIC-I2C clearance **0.1800 mm**.

Tested relocations:

- (103.750, 116.750): shorts/violates `/BAT_PROTECTED` on B.Cu;
- (102.300, 116.750): collides with J2 PTH GND pad at (102.070, 115.922);
- (104.600, 116.750): collides with U3 exposed GND pad and existing internal
  `/BQ_QON_N` copper;
- local 0.60 mm BAT detour: collides with J2 GND and `/BQ_PG_N`; rejected and
  not retained.

The F.Cu fanout is also bounded by `/BQ_STAT` immediately to the left and the
U3 GND/pad field to the right.

### U3 pad 12 — `/BQ_QON_N` — (107.250, 118.000) mm

A 0.25/0.15 mm full-stack PTH at the pad causes:

- direct conflict with J8 `/OLED_SDA` pad at (106.400, 118.120);
- effective hole clearance **0.0000 mm**;
- clearance to `/OLED_SCL` on In4 **0.0768 mm** versus 0.2000 mm required.

The downward F.Cu escape crosses the existing `/BQ_INT_N` via/track at
(107.8628, 118.6517) and the nearby `/BAT_PROTECTED` field.  Left/right doglegs
were also rejected by native DRC.

### Other retained open fine-pitch cells

The remaining open set includes U13 control pins, U4 high-impedance nodes,
camera rails and several long control routes.  Automated local routing at
0.25, 0.15 and 0.10 mm grids was attempted with 0.18 mm tracks and 0.20–0.22 mm
clearance.  Paths were retained only when native KiCad DRC stayed clean.

## Attempts performed

1. Full inventory of all 254 original microvias.
2. Direct same-coordinate PTH conversion with intermediate-layer audit.
3. Functional net rip-up limited to the 30 non-GND microvia-using nets.
4. Native KiCad A* routing on five signal layers; In1 remained the GND plane.
5. PTH sizes from 0.25/0.15 mm upward for power nets.
6. Grid passes at 0.25, 0.15 and 0.10 mm.
7. Restoration of validated R59 pad escapes without restoring microvias.
8. Explicit U3/U13/U4 terminal fanout and via-in-pad conflict mapping.
9. Zone refill and native DRC after every accepted/rejected batch.

No DRC category was suppressed and no drill files were merged artificially.

## Minimal proposed design change

Closing R5.10 as standard-PTH-only requires an authorized local placement and
routing rework around U3/J8:

1. move J8 and/or U3 enough to create a real PTH fanout corridor for U3 pads;
2. reroute `/BAT_PROTECTED`, `/BQ_STAT` and `/BQ_INT_N` locally while preserving
   power width and the validated U13/U4 BAT topology;
3. keep at least the native hole/copper clearance on every internal layer;
4. re-route the remaining 34 opens and rerun the complete gate.

An alternative is a formally quoted filled/capped through-via-in-pad process,
but it still requires intermediate-layer copper clearance and assembly approval;
it is not equivalent to the requested standard JLCPCB PTH process.

## Evidence

- `R5_10_DRC_BLOCKED_WIP.json`
- `R510_VIA_IN_PAD_CONFLICT_MAP_DRC.json`
- `R510_PMIC_SCL_LEFT_ESCAPE_DRC.json`
- `R510_PMIC_SCL_RIGHT_ESCAPE_DRC.json`
- `R510_PMIC_VIP_BAT_DETOUR_DRC.json`
- `R5_10_MICROVIA_TO_THROUGHVIA_AUDIT.csv`

