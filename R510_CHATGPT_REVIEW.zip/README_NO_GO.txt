R5.10 is NOT fabrication ready.

The WIP board has 6 copper layers, 155 footprints, zero microvias and 324
standard through vias, but it still has 34 native unconnected items.

Do not upload this folder to JLCPCB.
Read AUDIT/R5_10_TRUE_HARD_BLOCKER_REPORT.md and
AUDIT/R5_10_FINAL_GATE_REPORT.md.
